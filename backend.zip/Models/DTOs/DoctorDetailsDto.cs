﻿namespace Hospital_Management_system.Models.DTOs
{
    public class DoctorDetailsDto
    {
        public string FullName { get; set; }
        public string Specialisation { get; set; }
        public string HPID { get; set; }
        public string ContactNo { get; set; }
    }

}
